# This file is being maintained by Puppet.
# DO NOT EDIT

# put sbin dirs in the default PATH

pathmunge /usr/local/sbin
pathmunge /usr/sbin
pathmunge /sbin
